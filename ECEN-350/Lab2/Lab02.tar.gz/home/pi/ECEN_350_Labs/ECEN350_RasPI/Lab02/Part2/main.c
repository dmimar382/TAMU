extern long long int test();

int main(void)
{
	test();
	lab02b();
    return 0;
}
