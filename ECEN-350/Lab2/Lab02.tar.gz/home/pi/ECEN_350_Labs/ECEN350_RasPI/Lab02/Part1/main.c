extern long long int test();

int main(void)
{
	test();
    return 0;
}
