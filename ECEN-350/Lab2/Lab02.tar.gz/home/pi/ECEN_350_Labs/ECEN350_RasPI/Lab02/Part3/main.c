extern long long int test();
extern void lab02c(long long int a);

int main(void)
{
	test();
	lab02c(6);
    return 0;
}
