extern long long int lab02d(long long int);

int main()
{
    lab02d(100);
    return 0;
}
