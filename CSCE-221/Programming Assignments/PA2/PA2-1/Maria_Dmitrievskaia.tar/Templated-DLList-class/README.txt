Maria Dmitrievskaia, UIN : 927009911, Section 511, User Name : dmimar382, Email : dmimar382@tamu.edu

Sources used: N/A

I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work. On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.
Maria Dmitrievskaia 02/28/20

No known problems with the code. 

Pseudocode: The written code represents a templated doubly linked list class. I am able to create nodes that are connected in a list and preform insertion operations before the first node, after the last node,
as well as insertion anywhere in the middle of the list. I am also able to remove the first node, last node, or any node in the list. The copy constructor, move constructor, 
copy assignment operator and move assignment operator are fully operational. 
 


 
Program testing:
While writing the program, I tested every function to ensure its propper operation. For more details, please see TDLList-main.cpp. 


