Maria Dmitrievskaia, UIN : 927009911, Section 511, User Name : dmimar382, Email : dmimar382@tamu.edu

Sources used: lecture slides

I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work. On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.
Maria Dmitrievskaia 02/04/20

No known problems with the code. 

Pseudocode: The written code represents a collection for organizing stress balls with 4 different colors and 3 sizes to choose from.
Each ball has a color and size. The code implements many functions that are used to manipulate the collections, such as inserting a stress ball into the collection,
removing an item from the collection, combining collections, swaping collections, and sorting the collections using different sorting algorithms: 
bubble sort, insertion sort, and selection sort.   
 


 
Program testing:
While writing the program, I tested every function to ensure its propper operation. For more details, please see collection_test.cpp 

