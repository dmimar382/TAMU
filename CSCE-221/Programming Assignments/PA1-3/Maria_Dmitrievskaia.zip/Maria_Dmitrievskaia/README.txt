Maria Dmitrievskaia, UIN : 927009911, Section 511, User Name : dmimar382, Email : dmimar382@tamu.edu

Sources used: N/A

I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work. On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.
Maria Dmitrievskaia 02/16/20

No known problems with the code. 

Pseudocode: The written code represents a template of the collection class. It is capable of organizing and sorting different 
classes with a color and size attribute. The code implements many functions that are used to manipulate the collections, such 
as inserting an object into the collection, removing an object from the collection, combining collections, swaping collections, and sorting the collections using different sorting algorithms: 
bubble sort, insertion sort, and selection sort.   
 


 
Program testing:
While writing the program, I tested every function to ensure its propper operation. For more details, please see collection_test.cpp. 




Question 4:
Generic programming in c++ allows the programmer to not have to rewrite similar code multiple times. It allows to use the template code 
for a variety of different applications. With templates, many different, in this case, collections, can be created, as long as the objects
have a color and size attribute. This saves not only time for the programmer, but also allows for less space to be used in memory.   

