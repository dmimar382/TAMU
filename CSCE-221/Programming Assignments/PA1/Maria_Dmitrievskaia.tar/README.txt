Maria Dmitrievskaia, UIN : 927009911, Section 511, User Name : dmimar382, Email : dmimar382@tamu.edu

Sources used: https://en.cppreference.com/w/cpp/language/enum

I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work. On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.
Maria Dmitrievskaia 01/16/20

No known problems with the code. 

Pseudocode: The written code represents a collection for organizing stress balls with 4 different colors and 3 sizes to choose from.
Each ball has a color and size. The code compares if two created stress balls are the same using the == operator. 
A function for the output operator was also declaired and defined, that outputs the stess balls color and size in the following format: (color, size). 

 
Program testing:
A main components of any class is the default constructor, along with the parameterized constructor. To test the constructors, I used a test
file the professor gave us, which created 5 different stress balls. I observed that none of them had the same combination of color and size. 
I then tested the parameterized construction by passing a color and size to the constructor. The code Dr. Leyk also provided a comparison test
of two stress balls, in which I was able to see if any of the stress balls created by the default constructor were equal to the stess balls 
created by the parameterized constructor.   

